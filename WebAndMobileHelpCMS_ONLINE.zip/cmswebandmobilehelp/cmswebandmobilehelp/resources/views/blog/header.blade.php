<div class="page-tabs">
    <div class="row">
        <div class="">
            <p class="py-2 {{$active == "blog" ? 'active' : ''}}"><a href="/blog">Blog</a></p>
        </div>
        <div class="">
            <p class="py-2 {{$active === "blogcategory" ? 'active' : ''}}"><a href="/blogcategory">Category</a></p>
        </div>
    </div>
</div>
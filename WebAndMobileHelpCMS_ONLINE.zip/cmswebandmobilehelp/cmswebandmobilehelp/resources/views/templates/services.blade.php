<p class="pt-4"><span class="lead text-uppercase">Services Page</span><span></span></p>
          <div>
            <table class="table">
              <tr>
                <th>S/N</th>
                <th>Current Services</th>
                <th>Action</th>
              </tr>
            </table>
            <div class="text-center mt-5">
              <button class="bg-info px-3 py-2 border"><i class="fa fa-plus text-primary mr-2" aria-hidden="true"></i>Add new service</button>
            </div>
          </div>
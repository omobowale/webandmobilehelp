


<?php $__env->startSection('page-content'); ?>

this is my page

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cmswebandmobilehelp\resources\views/pages/homepage.blade.php ENDPATH**/ ?>


<?php $__env->startSection('tabcontent'); ?>
    <?php if(isset($message)): ?>
        <p class="alert alert-success"><?php echo e($message); ?></p>
    <?php endif; ?>
    <?php echo $__env->make('address.index', $addresses, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('email.index', $emails, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('phone.index', $phones, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/contact/index.blade.php ENDPATH**/ ?>
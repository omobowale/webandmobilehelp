

<?php $__env->startSection('tabcontent'); ?>

 <div class="table-responsive table-bordered settings-div">
 <table class="settings-table table table-hover">
    <tr>
      <th>Website Name</th>
    </tr>
    <tr class="webname-row" id="<?php echo e($settings->id); ?>">
        <td><?php echo e($settings->webname); ?></td>
    </tr>
  </table>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/settings/index.blade.php ENDPATH**/ ?>
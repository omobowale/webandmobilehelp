


<?php $__env->startSection('tabcontent'); ?>

<div class="bg-info fixed floating-button" >
    <a href="/blog/create"><i class="fa fa-plus text-white" aria-hidden="true"></i></a>
</div>
    
    <div class="container-fluid m-0 p-0">
        <?php echo $__env->make("pages.header", ["active" => "blogpage"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
  
    <?php if(isset($blog)): ?>
        <div class="page-tabs-content">
            <h4 class="text-center text-uppercase my-5" style="font-weight: bold">Post</h4>
            
                <div class="card mb-5" style="cursor: pointer" onclick="location='/blog/<?php echo e($blog->id); ?>/edit'" >
                    <div class="card-header">
                        <p class="card-title lead"><?php echo e($blog->title); ?></p>
                    </div>
                    <div class="card-body" style="position: relative">
                        <div class="pb-5">
                            <?php echo $blog->content; ?>

                        </div>
                        <hr/>
                        <div style="">
                            <p class="p-0 m-0"><small class="general-text-color" style="font-weight: bold">Category: </small> <?php echo e($blog->category->name); ?></p>
                            <p class="p-0 m-0"><small class="general-text-color" style="font-weight: bold">Hash Tags: </small> <?php echo e($blog->hash_tags); ?></p>
                            <p class="p-0 m-0"><small class="general-text-color" style="font-weight: bold">Meta Title: </small> <?php echo e($blog->meta_title); ?></p>
                            <p class="p-0 m-0"><small class="general-text-color" style="font-weight: bold">Meta Description: </small> <?php echo e($blog->meta_description); ?></p>
                            <p class="p-0 m-0"><small class="general-text-color" style="font-weight: bold">Date Posted: </small> <?php echo e($blog->created_at); ?></p>
                        </div>
                    </div>
                    <div class="card-footer container">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="general-text-color" style="font-weight: bold">Pending Comments : </div>
                                <div class="general-text-color" style="font-weight: bold">Approved Comments: </div>
                                <div class="general-text-color" style="font-weight: bold">All Comments :</div>
                            </div>
                            <div class="col-md-4 text-right" style="display: grid; grid-template-columns: repeat(2, 1fr); align-items: center;">
                                    <div class="text-info"><a href="/blog/<?php echo e($blog->id); ?>/edit" class="text-info" style="font-weight: bold">Edit</a></div>
                                    <div class="text-danger" style="font-weight: bold">Delete</div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    <?php endif; ?>

    <div class="text-center">
        <a href="/blog" class="btn btn-info">Back</a>
    </div>
     
        
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cmswebandmobilehelp\resources\views/pages/blogpage/show.blade.php ENDPATH**/ ?>
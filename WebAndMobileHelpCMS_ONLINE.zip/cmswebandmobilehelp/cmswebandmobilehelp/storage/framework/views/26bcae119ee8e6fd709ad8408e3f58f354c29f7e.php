


<?php $__env->startSection('tabcontent'); ?>


<?php echo $__env->make("blog.header", ["active" => "blog"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <?php if(isset($blog)): ?>
        <h3 class="mt-5 mb-4"><?php echo e($blog->title); ?></h3>
    <?php endif; ?>

    <?php if(isset($comments) && count($comments) > 0): ?>
        <table class="table table-responsive w-100">
            <thead>
                <tr class="w-100">
                    <th style="width: 5%">S/N</th>
                    <th style="width: 45%">Comment</th>
                    <th style="width: 10%">Writer</th>
                    <th style="width: 10%">Status</th>
                    <th style="width: 20%">Date Sent</th>
                    <th style="width: 10%">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($comment->id); ?>" class="comment-row">
                        <td><?php echo e($index + 1); ?></td>
                        <td class="comment-content"><?php echo e($comment->comment_content); ?></td>
                        <td class="">
                            <?php if($comment->commentator_id != 0): ?>
                                <?php echo e($comment->commentator->name); ?>

                            <?php elseif($comment->commentator_id == 0 && $comment->admin_id == Auth::user()->id): ?>
                                <?php echo e("You"); ?>

                            <?php else: ?>
                                Admin: <?php echo e(App\User::find($comment->admin_id)->name); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($comment->status == "Pending"): ?>
                                <span class="text-danger" style="font-weight: bold"><?php echo e($comment->status); ?></span>    
                            <?php else: ?>
                                <span class="text-success" style="font-weight: bold"><?php echo e($comment->status); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($comment->created_at); ?></td>
                        <td>
                            <?php if($comment->status == "Pending"): ?>
                                <a href="/update-comment-status/<?php echo e($comment->id); ?>"><span class="text-info" style="font-weight: bold">Approve</span></a>
                            <?php endif; ?>
                            <form action="/comments/<?php echo e($comment->id); ?>" class="form-inline" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="text-danger p-0 m-0" style="background: none; border:0; font-weight: bold" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <span class="text-info">Click on a comment to edit it</span>
            </tfoot>
        </table>


        
    <div>
        <button class="btn btn-block general-bg-color text-white" data-target="#add-comment-modal" data-toggle="modal">Add Comment</button>
    </div>        
    <div class="" style="width: 100%; display: grid; justify-content: center; align-items: center"><?php echo e($comments->links()); ?></div>
    <?php else: ?>

    <div class="text-info mt-5">
        No comments yet
    </div>

    <?php endif; ?>


    <div class="text-center mb-5 mt-5">
        <a href="<?php echo e(route('blog.show', $blog->id)); ?>" class="general-text-color" style="font-weight: bold;"><span style="text-decoration: underline">Back</span></a>
    </div>
 
</div>




<div class="modal offset-md-2 col-md-8" id="edit-comment-modal">
    <form id="edit-comment-form" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Edit Comment</h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Comment</label>
                    <textarea class="form-control" name="comment_content" id="comment_content" required placeholder="Please enter comment"></textarea>
                </div>
                <div class="form-group">
                    <select class="form-control" name="status" id="status">
                        <option value="Pending">Pending</option>
                        <option value="Approved">Approved</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button class="bg-danger px-3 py-2 text-white border" type="button" data-dismiss="modal" data-target="#edit-comment-modal">Cancel</button>
                <button class="general-bg px-3 py-2 text-white border" type="submit">Update</button>
            </div>
        </div>
    </form>
</div>

<div class="modal offset-md-2 col-md-8" id="add-comment-modal">
    <form id="add-comment-form" method="POST" action="/comments">
        <?php echo csrf_field(); ?>
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Add Comment</h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <input type="hidden" name="blog_id" value="<?php echo e($blog->id); ?>" />
            <input type="hidden" name="admin" value="admin" />
            <div class="modal-body">
                <div class="form-group">
                    <label>Comment</label>
                    <textarea class="form-control" name="comment_content" id="comment_content" required placeholder="Please enter comment"></textarea>
                </div>
                
            </div>
            <div class="modal-footer">
                <button class="bg-danger px-3 py-2 text-white border" type="button" data-dismiss="modal" data-target="#edit-comment-modal">Cancel</button>
                <button class="general-bg px-3 py-2 text-white border" type="submit">Add</button>
            </div>
        </div>
    </form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cmswebandmobilehelp\resources\views/blog/comments/index.blade.php ENDPATH**/ ?>
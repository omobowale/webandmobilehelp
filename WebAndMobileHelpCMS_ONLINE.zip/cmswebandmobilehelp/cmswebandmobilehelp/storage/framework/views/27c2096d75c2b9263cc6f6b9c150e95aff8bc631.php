<?php $__env->startSection('content'); ?>
    <div class="container text-center">
        <div class="jumbotron">
            <h1 class="mb-5">WELCOME</h1>
            <h2 class="mb-2 text-muted">BrilloConnetz</h2>
            <div>
                <p class="lead mb-5">Content Management System</p>
                <a href="/page" class="bg-info text-white border border-primary py-3 px-5">Get Started</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/welcome.blade.php ENDPATH**/ ?>
<div class="table-responsive mt-5 table-bordered">
    <div class="card">
        <div class="card-header">
            <p class="card-title text-center lead">Phones</p>
        </div>
        <div class="card-body">
            
            
                <table class="table table-hover contact-phone-table">
                    <tr>
                      <th>S/N</th>
                      <th>Phone</th>
                    </tr>
                    <?php $__currentLoopData = $phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="phone" id="<?php echo e($phone->id); ?>">
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($phone->phone); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>
                
           
            <hr>
            <div class="new-phone-form">
                <form id="create-new-phone-form" method="POST" action="/contact">
                    <?php echo csrf_field(); ?>
                    <h3>Add New phone</h3>
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input class="form-control" type="text" name="phone" id="phone" placeholder="Please enter phone" required />
                    </div>
                    <button class="bg-info px-3 py-2 text-white border" type="submit">Add</button>
                </form>
            </div>
        </div>
        
    </div>
</div><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/phone/index.blade.php ENDPATH**/ ?>
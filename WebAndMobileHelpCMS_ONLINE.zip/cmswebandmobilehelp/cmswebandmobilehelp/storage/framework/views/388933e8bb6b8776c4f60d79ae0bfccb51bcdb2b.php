<div class="page-tabs">
    <div class="row">
        <div class="">
            <p class="py-2 <?php echo e($active == "homepage" ? 'active' : ''); ?>"><a href="/homepage">Home</a></p>
        </div>
        <div class="">
            <p class="py-2 <?php echo e($active === "aboutpage" ? 'active' : ''); ?>"><a href="/aboutpage">About</a></p>
        </div>
        <div class="">
            <p class="py-2 <?php echo e($active == "servicespage" ? 'active' : ''); ?>"><a href="/servicespage">Services</a></p>
        </div>
        <div class="">
            <p class="py-2 <?php echo e($active == "portfoliopage" ? 'active' : ''); ?>"><a href="/portfoliopage">Portfolio</a></p>
        </div>
        <div class="">
            <p class="py-2 <?php echo e($active == "contactpage" ? 'active' : ''); ?>"><a href="/contactpage">Contact</a></p>
        </div>
        <div class="">
            <p class="py-2 <?php echo e($active == "commonspage" ? 'active' : ''); ?>"><a href="/commons">Commons</a></p>
        </div>
        <div class="">
            <p class="py-2 <?php echo e($active == "blogpage" ? 'active' : ''); ?>"><a href="/blogpage">Blog</a></p>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\cmswebandmobilehelp\resources\views/pages/header.blade.php ENDPATH**/ ?>
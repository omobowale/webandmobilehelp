

<?php $__env->startSection('tabcontent'); ?>
  
<div class="table-responsive table-bordered">
  <p class="alert card-header mb-0">Portfolio</p>
  <table class="portfolios-table table table-hover">
    <tr>
      <th>Portfolio ID</th>
      <th>Portfolio Name</th>
      <th>Portfolio Image</th>
      <th>Portfolio Link</th>
      <th>Portfolio Category</th>
      <th>Portfolio Description</th>
    </tr>
    <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
    <tr class="portfolio-row" id="<?php echo e($portfolio->id); ?>">
      <td><?php echo e($portfolio->id); ?></td>
      <td><?php echo e($portfolio->name); ?></td>
      <td><img class="portfolio-icon" src="<?php echo e($portfolio->imageUrl); ?>" /></td>
      <td><?php echo $portfolio->portfolio_link; ?></td>
      <td><?php echo e($portfolio->category); ?></td>
      <td><?php echo e($portfolio->short_description); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <div class="text-center my-5">
    <button class="general-bg px-3 py-2 border" data-target="#create-portfolio-modal" data-toggle="modal"><i class="fa fa-plus text-primary mr-2" aria-hidden="true"></i>Add new portfolio</button>
  </div>
</div>


<div class="table-responsive table-bordered">
  <p class="alert card-header mb-0">Portfolio Categories</p>
  <table class="portfolios-table table table-hover">
    <tr>
      <th>Category ID</th>
      <th>Category Name</th>
    </tr>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
    <tr class="category-row" id="<?php echo e($category->id); ?>">
      <td><?php echo e($category->id); ?></td>
      <td><?php echo e($category->name); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>



  <div class="px-2 mb-5">
    <form id="add-new-category-form" method="post" action="/category" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <p class="lead">Add a new category</p>
      <div class="form-group">
          <label for="name">Name:</label>
          <input class="form-control" id="name" name="name" type="text" placeholder="Enter category name" required/>
      </div>
      <button class="btn btn-block general-bg py-2">Add Category</button>
    </form>
  </div>



</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cmswebandmobilehelp\resources\views/portfolio/index.blade.php ENDPATH**/ ?>
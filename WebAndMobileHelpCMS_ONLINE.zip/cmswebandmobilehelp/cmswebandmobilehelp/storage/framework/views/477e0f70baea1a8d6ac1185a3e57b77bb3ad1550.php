<?php $__env->startSection('tabcontent'); ?>

 <div class="table-responsive table-bordered members-div">
 <table class="members-table table table-hover">
    <tr>
      <th>Member Id</th>
      <th>Member Name</th>
      <th>Member Role</th>
      <th>Member Gender</th>
      <th>Member Photo</th>
    </tr>
    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="member-row" id="<?php echo e($member->id); ?>">
          <td><?php echo e($member->id); ?></td>
          <td><?php echo e($member->name); ?></td>
          <td><?php echo e($member->role); ?></td>
          <td><?php echo e($member->gender); ?></td>
          <td><?php if($member->photo): ?> <img src="<?php echo e($member->photo); ?>" class="member-image"/> <?php endif; ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </table>
  <div class="text-center mt-5">
    <button class="bg-info px-3 py-2 border" data-target="#create-member-modal" data-toggle="modal"><i class="fa fa-plus text-primary mr-2" aria-hidden="true"></i>Add new member</button>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/team/index.blade.php ENDPATH**/ ?>
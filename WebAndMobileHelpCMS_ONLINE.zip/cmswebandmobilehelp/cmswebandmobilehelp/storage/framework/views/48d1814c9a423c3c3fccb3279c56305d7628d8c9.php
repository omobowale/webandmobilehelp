<div class="table-responsive table-bordered contactpage-div">
    <div class="card">
        <div class="card-header">
            <p class="card-title text-center lead">Details</p>
        </div>
        <div class="card-body">
            <table class="table table-hover">
                <tr>
                  <th>Page Name</th>
                  <th>Page Title</th>
                  <th>Page Description</th>
                </tr>
                <tr class="page-row" title="contact" id="4">
                 
                </tr>
              </table>
        </div>
        <div class="card-footer">
            <small class="text-info">Click on the row to edit details</small>
        </div>
    </div>
</div><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/contactpage/index.blade.php ENDPATH**/ ?>
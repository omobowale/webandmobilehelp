<div class="modal offset-md-2 col-md-8" id="create-service-modal">
    <form id="add-new-service-form" method="post" action="/service">
        <?php echo csrf_field(); ?>
        <div class="modal-content">
            <div class="modal-header">
                <p class="lead">Add a new service</p>
            </div>  
            <div class="modal-body">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input class="form-control" id="name" name="name" type="text" placeholder="Enter service name" required/>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea rows="7" class="form-control" id="description" type="text" name="description" placeholder="Enter service description" ></textarea>
                </div>
                <div class="form-group">
                    <label for="slug">Slug: (Optional)</label>
                    <input class="form-control" id="slug" name="slug" type="text" placeholder="Enter service slug for SEO performance"/>
                </div>
            </div>  
            <div class="modal-footer">
                <button type="submit" class="bg-info py-2 px-3 border">Add</button>
                <button type="button" data-dismiss="modal" data-target="#create-service-modal" class="bg-danger py-2 px-3 border">Cancel</button>
            </div>  
        </div>
    </form>
</div><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/service/create.blade.php ENDPATH**/ ?>
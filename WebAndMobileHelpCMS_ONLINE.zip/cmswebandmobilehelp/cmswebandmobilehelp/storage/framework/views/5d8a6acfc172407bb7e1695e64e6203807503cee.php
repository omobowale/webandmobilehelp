<div class="table-responsive table-bordered mt-5">
    <div class="card">
        <div class="card-header">
            <p class="card-title text-center lead">Emails</p>
        </div>
        <div class="card-body">
            
            
                <table class="table table-hover contact-email-table">
                    <tr>
                      <th>S/N</th>
                      <th>Email</th>
                    </tr>
                    <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="email" id="<?php echo e($email->id); ?>">
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($email->email); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>
                
           
            <hr>
            <div class="new-email-form">
                <form id="create-new-email-form" method="POST" action="/contact">
                    <?php echo csrf_field(); ?>
                    <h3>Add New email</h3>
                    <div class="form-group">
                        <label>Email</label>
                        <input class="form-control" type="email" name="email" id="email" placeholder="Please enter email" required />
                    </div>
                    <button class="bg-info px-3 py-2 text-white border" type="submit">Add</button>
                </form>
            </div>
        </div>
        
    </div>
</div><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/email/index.blade.php ENDPATH**/ ?>
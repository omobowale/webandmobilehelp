<div class="page-tabs">
    <div class="row">
        <div class="">
            <p class="py-2 <?php echo e($active == "blog" ? 'active' : ''); ?>"><a href="/blog">Blog</a></p>
        </div>
        <div class="">
            <p class="py-2 <?php echo e($active === "blogcategory" ? 'active' : ''); ?>"><a href="/blogcategory">Category</a></p>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\cmswebandmobilehelp\resources\views/blog/header.blade.php ENDPATH**/ ?>
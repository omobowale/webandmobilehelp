

<?php $__env->startSection('tabcontent'); ?>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <p class="pt-4"><span class="lead text-uppercase" id="page-title"><?php echo e($page->name); ?> PAGE</span></p>
    <div class="table-responsive table-bordered mb-5">
        <div class="card">
            <div class="card-header">
                <p class="card-title text-center lead">Details</p>
            </div>
            <div class="card-body">
                <table class="table table-hover">
                    <tr>
                        <th>Page Name</th>
                        <th>Page Title</th>
                        <th>Page Description</th>
                        <th>Page Meta Title</th>
                        <th>Page Meta Description</th>
                    </tr>
                    <tr class="page-row" id="<?php echo e($page->id); ?>" title="<?php echo e($page->name); ?>">
                        <td><?php echo e($page->name); ?></td>
                        <td><?php echo e($page->title); ?></td>
                        <td><?php echo e($page->description); ?></td>
                        <td><?php echo e($page->meta_title); ?></td>
                        <td><?php echo e($page->meta_description); ?></td>
                    </tr>
                </table>
            </div>
            <div class="card-footer">
                <small class="text-info">Click on the row to edit details</small>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/pages/index.blade.php ENDPATH**/ ?>
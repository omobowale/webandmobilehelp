<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-0">
    <?php echo e(session('status')); ?>

    <div class="row border border-secondary">

    
          
          <div class="col-md-2 left-sidebar text-white p-0 fixed-left">
            <div class="profile-picture text-center pt-5 pb-3">
              <i class="fa fa-user-circle fa-4x" aria-hidden="true"></i>
              <p class="lead pt-3 text-uppercase"><?php echo e(Auth::user()->name); ?></p>
              <hr/>
            </div>
            <div class="menu-list">
              <div class="accordion" id="">
                <div class="lead border border-primary menu-name pl-3 pb-3 pt-4" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                  <p><i class="fa fa-columns text-primary mr-2" aria-hidden="true"></i>
                    <span class="label"><a href="/homepage">Site Pages</a></span>
                  </p>
                </div>
              </div>


              <div class="accordion" id="site-content">
                <div class="lead border border-primary menu-name pl-3 pb-3 pt-4" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                  <p><i class="fa fa-briefcase text-primary mr-2" aria-hidden="true"></i>
                    <span class="label">Site Content</span><i class="fa fa-arrow-circle-down ml-3" aria-hidden="true"></i>
                  </p>
                </div>
                <div id="collapseThree" class="collapse show" aria-labelledby="headingTwo" data-parent="#site-content">
                  <ul class="py-4" style="list-style: none; padding:0; padding-left:1.2em; background-color:#24344b">
                    <li class="link3" id="logo" name="logo"><a href="/logo">Site Logo</a></li>    
                    <li class="link3" id="services"><a href="/service">All Services</a></li>          
                    <li class="link3" id="portfolio"><a href="/portfolio">Portfolio</a></li>          
                    <li class="link3" id="team-members"><a href="/team">Team Members</a></li>          
                    <li class="link3" id="contact-details"><a href="/contact">Contact Details</a></li>          
                    <li class="link3" id="blog"><a href="/blog">Blog</a></li>          
                  </ul>
                </div>
              </div>
              

              <div class="accordion" id="site-sections">
                <div class="lead border border-primary menu-name pl-3 pb-3 pt-4" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                  <p><i class="fa fa-bars text-primary mr-2" aria-hidden="true"></i>
                    <span class="label">Site Sections</span><i class="fa fa-arrow-circle-down ml-3" aria-hidden="true"></i>
                  </p>
                </div>
                <div id="collapseTwo" class="collapse show" aria-labelledby="headingOne" data-parent="#site-sections">
                  <ul class="py-4" style="list-style: none; padding:0; padding-left:1.2em; background-color:#24344b">
                      
                      <li><a href="/footer">Footer</a></li>
                  </ul>
                </div>
              </div>

              

              <div class="accordion" id="site-others">
                <div class="lead border border-primary menu-name pl-3 pb-3 pt-4" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
                  <p><i class="fa fa-plus text-primary mr-2" aria-hidden="true"></i>
                    <span class="label">Site Others</span><i class="fa fa-arrow-circle-down ml-3" aria-hidden="true"></i>
                  </p>
                </div>
                <div id="collapseFour" class="collapse show" aria-labelledby="headingTwo" data-parent="#site-others">
                  <ul class="py-4" style="list-style: none; padding:0; padding-left:1.2em; background-color:#24344b">
                    <li class="link2"><a href="/settings">Settings</a></li>      
                    <?php if(Auth::user()->role == "superadmin"): ?>
                      <li class="link2"><a href="/admin">Edit Admins</a></li>      
                    <?php endif; ?>
                  </ul>
                </div>
              </div>
            </div>
          </div>

        
        <div class="col-md-9">
          
          
          <?php echo $__env->yieldContent('tabcontent'); ?>

          
          
        </div>

      
      <div class="col-md-1 right-sidebar p-0">
          <p class="text-center py-2"><a href="https://webandmobilehelp.com" target="_blank">Show main site</a></p>
      </div>
        
    </div>



    
    <?php echo $__env->make('pages.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('service.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('service.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('portfolio.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('portfolio.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('category.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('team.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('team.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('content.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('logo.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('contact.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('contact.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('settings.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admins.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('footer.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>


<div class="container-fluid px-0">
  <div class="footer py-3 text-center text-white" >
    <p>Copyrights &copy; 2020</p>
    <hr />
    <p>WebAndMobileHelp</p>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cmswebandmobilehelp\resources\views/template.blade.php ENDPATH**/ ?>



<?php $__env->startSection('tabcontent'); ?>
<p class="alert alert-info lead">This section is an advanced section and still in progress. It has no effect on the website page yet</p>
<div class="container my-3">
    <div class="row">
        <div class="col-xs-12 col-md-6 bg-success text-white about-us-left">
            <div class="jumbotron">
                <p>Who we are</p>
                <hr />
                <h4>BrilloConnetz focuses on providing quality but affordable automation, software, research & training...</h4>
                <button class="btn btn-light py-2 px-4 py-lg-3 px-lg-5 mt-5">Read More <span class="arrow"></span></button>
            </div>
        </div>
        <div class="col-xs-12 col-md-6 bg-danger about-us-right">

        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Downloads\brillobackend-main\resources\views/showcontent/index.blade.php ENDPATH**/ ?>
<div class="modal offset-md-2 col-md-8" id="edit-email-modal">
    <form id="edit-email-form" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="modal-content">
            <div class="modal-header">
                <h3>Edit Email</h3>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <input class="form-control" type="hidden" name="sc" id="sc"/>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input class="form-control" type="email" name="email" id="email" required placeholder="Please enter email"/>
                </div>
            </div>
            <div class="modal-footer">
                <button class="bg-info px-3 py-2 text-white border" type="submit">Update</button>
                <button class="bg-danger px-3 py-2 text-white border" type="button" data-dismiss="modal" data-target="#edit-email-modal">Cancel</button>
            </div>
        </div>
    </form>

    <div class="bg-dark py-2 text-center">
        <form class="" id="delete-email-form" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="text-danger delete">Delete</button>
        </form>
        
    </div>
    
</div><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/email/edit.blade.php ENDPATH**/ ?>



<?php $__env->startSection('tabcontent'); ?>
  
<div class="table-responsive table-bordered">
  <p class="alert card-header mb-0">Contact Details</p>
  <table class="services-table table table-hover">
    <tr>
      <th>Contact ID</th>
      <th>Location</th>
      <th>Address</th>
      <th>Email</th>
      <th>Email Contactable</th>
      <th>Phone</th>
    </tr>
    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
    <tr class="contact-row" id="<?php echo e($contact->id); ?>">
      <td><?php echo e($contact->id); ?></td>
      <td><?php echo e($contact->location); ?></td>
      <td><?php echo e($contact->address); ?></td>
      <td><?php echo e($contact->email); ?></td>
      <td><?php echo e($contact->email_contactable ? "yes" : "no"); ?></td>
      <td><?php echo e($contact->phone); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <div class="text-center mt-5">
    <button class="general-bg px-3 py-2 border" data-target="#create-contact-modal" data-toggle="modal"><i class="fa fa-plus text-primary mr-2" aria-hidden="true"></i>Add new contact</button>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cmswebandmobilehelp\resources\views/contact/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('tabcontent'); ?>
  
<div class="table-responsive table-bordered">
  <p class="alert card-header mb-0">All Services</p>
  <table class="services-table table table-hover">
    <tr>
      <th>Service ID</th>
      <th>Service Name</th>
      <th>Service Description</th>
      <th>Service Slug</th>
    </tr>
    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
    <tr class="service-row" id="<?php echo e($service->id); ?>">
      <td><?php echo e($service->id); ?></td>
      <td><?php echo e($service->name); ?></td>
      <td><?php echo $service->description; ?></td>
      <td><?php echo e($service->slug); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <div class="text-center mt-5">
    <button class="bg-info px-3 py-2 border" data-target="#create-service-modal" data-toggle="modal"><i class="fa fa-plus text-primary mr-2" aria-hidden="true"></i>Add new service</button>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/service/index.blade.php ENDPATH**/ ?>
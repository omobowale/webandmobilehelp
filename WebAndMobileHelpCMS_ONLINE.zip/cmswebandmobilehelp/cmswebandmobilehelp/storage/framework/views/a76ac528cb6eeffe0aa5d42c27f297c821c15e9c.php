<div class="table-responsive table-bordered mt-5 contact-div">
    <div class="card">
        <div class="card-header">
            <p class="card-title text-center lead">Addresses</p>
        </div>
        <div class="card-body">
            
            
                <table class="table table-hover contact-address-table">
                    <tr>
                      <th>S/N</th>
                      <th>Address</th>
                    </tr>
                    <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="address" id="<?php echo e($address->id); ?>">
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($address->address); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
       
            <hr>
            <div class="new-address-form">
                <form id="create-new-address-form" method="POST" action="/contact">
                    <?php echo csrf_field(); ?>
                    <h3>Add New Address</h3>
                    <div class="form-group">
                        <label>Address:</label>
                        <input class="form-control" type="text" name="address" id="address" placeholder="Please enter address" required />
                    </div>
                    <button class="bg-info px-3 py-2 text-white border" type="submit">Add</button>
                </form>
            </div>
        </div>
        
    </div>
</div><?php /**PATH C:\xampp\htdocs\cmswebandmobilehelp\resources\views/address/index.blade.php ENDPATH**/ ?>
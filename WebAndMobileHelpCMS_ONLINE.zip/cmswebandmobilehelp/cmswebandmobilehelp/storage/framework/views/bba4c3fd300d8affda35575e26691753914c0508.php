<?php $__env->startSection('tabcontent'); ?>
    

<div class="table-responsive table-bordered logo-div" id="">
    <div class="card">
        <div class="card-header">
            <p class="card-title text-center lead">Logo</p>
        </div>
        <div class="card-body">
            
            
                <table class="table table-hover logo-table">
                    <tr>
                      <th>Logo Name</th>
                      <th>Image</th>
                      <th>Image Alt</th>
                      <th>Currently in use</th>
                    </tr>
                    <?php $__currentLoopData = $logos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="<?php echo e($logo->id); ?>" class="logo">
                            <td><?php echo e($logo->name); ?></td>
                            <td><img class="logo-image" src="<?php echo e($logo->url); ?>" /></td>
                            <td><?php echo e($logo->alt); ?></td>
                            <td><?php echo e($logo->current == '1'? "yes" : "no"); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>
                
           
            <hr>
            <div class="new-logo-form">
                <form id="create-new-logo-form" method="POST" action="/logo" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <h3>Choose New Logo</h3>
                    <div class="form-group">
                        <input class="form-control" type="hidden" name="api_token" value="<?php echo e(Auth::user()->api_token ?? ''); ?>" required />
                    </div>
                    <div class="form-group">
                        <label>Logo Name</label>
                        <input class="form-control" type="text" name="name" id="name" required />
                    </div>
                    <div class="form-group">
                        <label>Choose Logo</label>
                        <input class="form-control" type="file" name="logo" id="logo" required />
                    </div>
                    <div class="form-group">
                        <label>Logo Alt</label>
                        <input class="form-control" type="text" name="alt" id="alt" />
                    </div>
                    <div class="form-group">
                        <label>Set as current logo</label>
                        <select class="form-control" name="current" id="current">
                            <option value="0">no</option>
                            <option value="1">yes</option>
                        </select>
                    </div>
                    <button class="bg-info px-3 py-2 text-white border" type="submit">Upload</button>
                </form>
            </div>
        </div>
        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/logo/index.blade.php ENDPATH**/ ?>
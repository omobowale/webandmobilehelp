<div class="modal offset-md-2 col-md-8" id="edit-service-modal">
    <form id="edit-service-form" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="modal-content">
            <div class="modal-header">
                <p class="lead">Edit a service</p>
            </div>  
            <div class="modal-body">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input class="form-control" id="name" name="name" type="text" placeholder="Enter service name" value="" required/>
                </div>
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea rows="7" class="form-control" id="service-description" type="text" name="description" placeholder="Enter service description" ></textarea>
                </div>
                <div class="form-group">
                    <label for="slug">Slug: (Optional)</label>
                    <input class="form-control" id="slug" name="slug" type="text" placeholder="Enter service slug for SEO performance"/>
                </div>
            </div>  
            <div class="modal-footer">
                <button type="submit" class="bg-info py-2 px-3 border">Update</button>
                <button type="button" data-dismiss="modal" data-target="#modal" class="bg-danger py-2 px-3 border">Cancel</button>
            </div>  
        </div>
    </form>

    <div class="bg-dark py-2 text-center">
        <form class="" id="delete-service-form" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="text-danger delete">Delete</button>
        </form>
        
    </div>
</div><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/service/edit.blade.php ENDPATH**/ ?>
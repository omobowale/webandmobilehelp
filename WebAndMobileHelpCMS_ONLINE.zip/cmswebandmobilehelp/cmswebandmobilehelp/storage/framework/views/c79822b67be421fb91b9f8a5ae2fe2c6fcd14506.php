


<?php $__env->startSection('tabcontent'); ?>
<div class="table-responsive table-bordered mt-5">
    <div class="card">
        <div class="card-header">
            <p class="card-title text-center lead">Footer Details</p>
        </div>
        <div class="card-body">
            
            
                <table class="table table-hover footer-table">
                    <tr>
                      <th>Website Name</th>
                      <th>Website Description</th>
                      <th>Copyrights Statement</th>
                    </tr>
                        <tr class="footer-row" id="<?php echo e($footer->id); ?>">
                            <td><?php echo e($footer->webname); ?></td>
                            <td><?php echo e($footer->webdescription); ?></td>
                            <td><?php echo e($footer->copyrightstatement); ?></td>
                        </tr>
                  </table>
                
           
            <hr>
            
        </div>
        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cmswebandmobilehelp\resources\views/footer/index.blade.php ENDPATH**/ ?>
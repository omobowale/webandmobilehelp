


<?php $__env->startSection('tabcontent'); ?>

<div class="table-responsive table-bordered mt-5">
    <div class="card">
        <div class="card-header">
            <p class="card-title text-center lead">Content Details</p>
        </div>
        <div class="card-body">
            
            
                <table class="table table-hover content-table">
                        <tr>
                            <th style="width: 10%">Page</th>
                            <th style="width: 30%">Item</th>
                            <th style="width: 60%">Value</th>
                        </tr>
                        <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                            <?php if($content->item === "home_one_image"): ?>
                                <tr class="content-row" id="<?php echo e($content->id); ?>" name="image" data-info="<?php echo e($content->info); ?>">
                                    <td><?php echo e($content->page_name); ?></td>
                                    <td><?php echo e($content->item); ?></td>
                                    <td name="image"><img class="logo-image" src=<?php echo e($content->value); ?> /></td>
                                </tr>
                            <?php else: ?>    
                                <tr class="content-row" id="<?php echo e($content->id); ?>" data-info="<?php echo e($content->info); ?>">
                                    <td><?php echo e($content->page_name); ?></td>
                                    <td><?php echo e($content->item); ?></td>
                                    <td><?php echo e($content->value); ?></td>
                                </tr>
                            <?php endif; ?>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                  </table>
            
        </div>
        
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Downloads\brillobackend-main\resources\views/content/index.blade.php ENDPATH**/ ?>
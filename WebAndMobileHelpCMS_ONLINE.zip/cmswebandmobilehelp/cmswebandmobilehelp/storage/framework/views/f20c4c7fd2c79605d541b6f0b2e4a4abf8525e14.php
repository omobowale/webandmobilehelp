


<?php $__env->startSection('tabcontent'); ?>

    <?php echo $__env->make("blog.header", ["active" => "blogcategory"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-tabs-content">
        <?php if(isset($blogcategories) && count($blogcategories) > 0): ?>
            <table class="table">
                <tr>
                    <th>S/N</th>
                    <th>Category</th>
                </tr>
            <?php $__currentLoopData = $blogcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $blogcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="blog-category-row" id="<?php echo e($blogcategory->id); ?>">
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($blogcategory->name); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

        <?php endif; ?>
    </div>


    <div class="mt-5">
        <h4 class="text-center">Add New Category</h4>
        <form method="POST" action="/blogcategory">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Name: </label>
                <input class="form-control" type="text" placeholder="Enter name of category" name="name" id="name"  />
            </div>
            <button class="btn btn-block general-bg-color text-white" type="submit">Add</button>
        </form>
    </div>
     
    <div class="modal offset-md-2 col-md-8" id="edit-blog-category-modal">
        <div class="modal-content">
            <form id="edit-blog-category-form" method="POST" > 
                <?php echo csrf_field(); ?>               
                <?php echo method_field('PUT'); ?>
                <div class="modal-header">
                    <h4 class="modal-title">Edit Category</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>                
                <div class="modal-body">
                    <div class="form-group">
                        <label>Name: </label>
                        <input class="form-control" type="text" placeholder="Enter name of category" name="name" id="name"  />
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-block general-bg-color text-white" type="submit">Update</button>
                </div>
            </form>
        </div>
        <div class="bg-dark py-2 text-center">
            <form class="" id="delete-blog-category-form" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="text-danger delete">Delete</button>
            </form>
            
        </div>
    </div>
     
        
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cmswebandmobilehelp\resources\views/blog/category/index.blade.php ENDPATH**/ ?>
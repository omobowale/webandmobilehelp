

<?php $__env->startSection('pagecontent'); ?>
<p class="pt-4"><span class="lead text-uppercase" id="page-title">HOME PAGE</span></p>
<div class="table-responsive table-bordered homepage-div">
    <div class="card">
        <div class="card-header">
            <p class="card-title text-center lead">Details</p>
        </div>
        <div class="card-body">
            <table class="table table-hover">
                <tr>
                  <th>Page Name</th>
                  <th>Page Title</th>
                  <th>Page Description</th>
                </tr>
                <tr class="page-row" title="home" id="1">
                  
                </tr>
              </table>
        </div>
        <div class="card-footer">
            <small class="text-info">Click on the row to edit details</small>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/pages/home.blade.php ENDPATH**/ ?>
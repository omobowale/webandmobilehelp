<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>" defer></script>
    
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />

    
    <link href="https://fonts.googleapis.com/css2?family=Zilla+Slab:wght@300&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-info shadow-sm">
            <div class="container pl-0 ml-0">
                <?php $logo = app('App\Logo'); ?>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img class="logo-image" src="<?php echo e($logo->getCurrentLogo()->url); ?>" alt=<?php echo e($logo->getCurrentLogo()->alt); ?> />
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                        
                        <!-- Right Side Of Navbar -->
                        <ul class="navbar-nav ml-auto">
                            <!-- Authentication Links -->
                            <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                            <?php endif; ?>
                        <?php else: ?>
                        <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>
                                    
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    



    
    <script>
        
    </script>
   <script>
        //Allow window to load before making ajax request
        window.addEventListener('load', function(){

            CKEDITOR.replace('description', {
                filebrowserUploadUrl: "<?php echo e(route('ckeditor.upload', ['_token' => csrf_token() ])); ?>",
                filebrowserUploadMethod: 'form'
            });

            CKEDITOR.replace('service-description', {
                filebrowserUploadUrl: "<?php echo e(route('ckeditor.upload', ['_token' => csrf_token() ])); ?>",
                filebrowserUploadMethod: 'form'
            });
            //CKEDITOR.replace( 'service-description' );
            

            // PAGES SECTION
                // =============================================================================
                // When the rows in the "pages" table are clicked
                // =============================================================================
                $(".page-row").click(function(e){
                    var page_id = $(this).attr("id");
                    var modalTitle = $(this).attr("title");
                    var pageTitle = $(this).find("td").first().text();
                    var pageName = $(this).find("td:nth-child(2)").text();
                    var pageDescription = $(this).find("td:nth-child(3)").text();
                    var pageMetaTitle = $(this).find("td:nth-child(4)").text();
                    var pageMetaDescription = $(this).find("td:nth-child(5)").text();
                    // console.log(pageTitle, pageName, pageDescription);
                    $("#edit-page-modal").modal('toggle');
                    $("#edit-page-modal").find("#edit-name").val(pageName);
                    $("#edit-page-modal").find("#edit-title").val(pageTitle);
                    $("#edit-page-modal").find("#edit-description").val(pageDescription);
                    $("#edit-page-modal").find("#edit-meta-title").val(pageMetaTitle);
                    $("#edit-page-modal").find("#edit-meta-description").val(pageMetaDescription);
                    $("#edit-page-form").attr("action", '/page/'+ page_id);
                    
                    
                });



            // SERVICES SECTION
                // =============================================================================
                // When any row of the SERVICES table is clicked
                // =============================================================================

                $(".service-row").click(function(e){
                    var service_id = $(this).attr("id");
                    var service_name = $(this).find("td:nth-child(2)").text();
                    var service_description = $(this).find("td:nth-child(3)").html();
                    var service_slug = $(this).find("td:nth-child(4)").text();

                    $("#edit-service-modal").modal('toggle');
                    $("#edit-service-modal").find("#name").val(service_name);
                    $("#edit-service-modal").find("#slug").val(service_slug);
                    CKEDITOR.instances['service-description'].setData(service_description)
                    $("#edit-service-form").attr("action", '/service/' + service_id);
                    $("#delete-service-form").attr("action", '/service/' + service_id);
                    
                });



//==============================================================================================                
//      TEAM SECTION
//==============================================================================================                
                // =============================================================================
                // When any row of the TEAM table is clicked
                // =============================================================================

                $(".member-row").click(function(e){
                    var member_id = $(this).attr("id");
                    var member_name = $(this).find("td:nth-child(2)").text();
                    var member_role = $(this).find("td:nth-child(3)").text();
                    var member_gender = $(this).find("td:nth-child(4)").text();

                    $("#edit-member-modal").modal('toggle');
                    $("#edit-member-modal").find("#name").val(member_name);
                    $("#edit-member-modal").find("#role").val(member_role);
                    $("#edit-member-modal").find("#gender").val(member_gender);
                    $("#edit-member-form").attr("action", '/team/' + member_id);
                    $("#delete-member-form").attr("action", '/team/' + member_id);
                    
                });                

//==============================================================================================                
//      SETTINGS SECTION
//==============================================================================================                
                // =============================================================================
                // When any row of the SETTINGS WEBNAME table is clicked
                // =============================================================================

                $(".webname-row").click(function(e){
                    var webname_id = $(this).attr("id");
                    var webname_webname = $(this).find("td:nth-child(1)").text();
                    console.log(webname_webname);
                    $("#edit-webname-modal").modal('toggle');
                    $("#edit-webname-modal").find("#webname").val(webname_webname);
                    $("#edit-webname-form").attr("action", '/settings/' + webname_id);
                });                

//==============================================================================================                
//      CONTACT DETAILS SECTION
//==============================================================================================                
                // =============================================================================
                // When any row of the CONTACT DETAILS table is clicked
                // =============================================================================

                //For address
                $(".address").click(function(e){
                    var address_id = $(this).attr("id");
                    var address_address = $(this).find("td:nth-child(2)").text();

                    $("#edit-address-modal").modal('toggle');
                    $("#edit-address-modal").find("#address").val(address_address);
                    $("#edit-address-form").attr("action", '/contact/' + address_id);
                    $("#delete-address-form").attr("action", '/address/' + address_id);
                    
                }); 

                //For email
                $(".email").click(function(e){
                    var email_id = $(this).attr("id");
                    var email_email = $(this).find("td:nth-child(2)").text();

                    $("#edit-email-modal").modal('toggle');
                    $("#edit-email-modal").find("#email").val(email_email);
                    $("#edit-email-form").attr("action", '/contact/' + email_id);
                    $("#delete-email-form").attr("action", '/email/' + email_id);
                    
                });                
                //For phone
                $(".phone").click(function(e){
                    var phone_id = $(this).attr("id");
                    var phone_phone = $(this).find("td:nth-child(2)").text();

                    $("#edit-phone-modal").modal('toggle');
                    $("#edit-phone-modal").find("#phone").val(phone_phone);
                    $("#edit-phone-form").attr("action", '/contact/' + phone_id);
                    $("#delete-phone-form").attr("action", '/phone/' + phone_id);
                    
                });                
                

//==============================================================================================                
//      LOGO SECTION
//==============================================================================================                
                // =============================================================================
                // When the logo link in the "site content" tab is clicked
                // =============================================================================
                $(".logo").click(function(){
                    var logo_id = $(this).attr("id");
                    modifyLogo(logo_id);
                });


                

                //When a row on the logos table is clicked
                function modifyLogo(id){
                 
                    //make an ajax call to the get the corresponding service
                    $.ajax({
                        url: "<?php echo e(url('/logo')); ?>" + "/" + id,
                        method: 'GET',
                        success: function(logo){
                          
                            var logo_id = logo.id;
                            var logo_name = logo.name;
                            var logo_url = logo.url;
                            var logo_alt = logo.alt;
                            var logo_current = logo.current;
                            $("#edit-logo-form").find("#name").val(logo_name);
                            $("#edit-logo-form").find("#current").val(logo_current);
                            $("#edit-logo-form").find("#alt").val(logo_alt);
                            $("#edit-logo-form").find("#sc").val(logo_id);
                            $("#edit-logo-form").attr("action", 'logo/'+logo_id);
                            $("#delete-logo-form").attr("action", 'logo/'+logo_id);
                            $("#edit-logo-modal").modal('show');

                        },

                        error: function(){
                            alert("Could not find page");
                        }
                    });
                    //call the edit modal
                }



// =============================================================================================================
//      All other functions
// =============================================================================================================
//                

    });
    </script>
    
</body>
</html><?php /**PATH C:\Users\PC\Downloads\brillobackend-master\resources\views/layouts/app.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <div class="container text-center">
        <div class="jumbotron">
            
            <h2 class="mb-2 text-muted">Account Creation</h2>
            <div>
                <p class="lead mb-5">A new account has been created for the user and a mail for verification has been sent to their email address. </p>
                <a href="/page" class="bg-info text-white border border-primary py-2 px-4">Go back to home page</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Downloads\brillobackend-main\resources\views/superadmin/registered.blade.php ENDPATH**/ ?>
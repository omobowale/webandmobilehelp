

<?php $__env->startSection('tabcontent'); ?>

<div class="container-fluid m-0 p-0">
    <div class="page-tabs">
        <div class="row">
            <div class="offset-md-1 col-md-2">
                <p class="p-3"><a href="homepage">Home</a></p>
            </div>
            <div class="col-md-2">
                <p class="p-3"><a href="aboutpage">About</a></p>
            </div>
            <div class="col-md-2">
                <p class="p-3"><a href="servicespage">Services</a></p>
            </div>
            <div class="col-md-2">
                <p class="p-3"><a href="portfoliopage">Portfolio</a></p>
            </div>
            <div class="col-md-2">
                <p class="p-3"><a href="contactpage">Contact</a></p>
            </div>
        </div>
    </div>
    <div class="page-tabs-content bg-secondary">
        <?php echo $__env->yieldContent('page-content'); ?>
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cmswebandmobilehelp\resources\views/pages/index.blade.php ENDPATH**/ ?>